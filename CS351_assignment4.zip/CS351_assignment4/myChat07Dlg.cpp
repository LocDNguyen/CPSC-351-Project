
// myChat07Dlg.cpp : implementation file
//

#include "pch.h"
#include "framework.h"
#include "myChat07.h"
#include "myChat07Dlg.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

CString cstr;
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CmyChat07Dlg dialog



CmyChat07Dlg::CmyChat07Dlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_MYCHAT07_DIALOG, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CmyChat07Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CmyChat07Dlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDOK, &CmyChat07Dlg::OnBnClickedOk)
	ON_BN_CLICKED(IDC_SEND, &CmyChat07Dlg::OnBnClickedSend)
	ON_BN_CLICKED(IDCANCEL, &CmyChat07Dlg::OnBnClickedCancel)
END_MESSAGE_MAP()


// CmyChat07Dlg message handlers

BOOL CmyChat07Dlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != nullptr)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CmyChat07Dlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CmyChat07Dlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CmyChat07Dlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


void CmyChat07Dlg::OnBnClickedOk()
{
	// TODO: Add your control notification handler code here
	CDialogEx::OnOK();
}


void CmyChat07Dlg::OnBnClickedSend()
{
	// TODO: Add your control notification handler code here
	//AfxMessageBox((LPCTSTR)"HI");
	CString typingChat ;
	GetDlgItemText(IDC_EDIT_CHAT, typingChat);
	//CString c;
	cstr += "Me: " + typingChat + "\r\n";

	// Write text from chat 
	SetDlgItemText(IDC_STATIC, cstr);
	//GetDlgItem(ID_CHAT_BOX)->SetWindowText("");
	//GetDlgItem()
	
	const char* pkt;
	pkt = typingChat;

	const char* srcIP = "137.151.175.192";
	const char* destIP = "127.0.0.1";

	sockaddr_in dest;
	sockaddr_in local;
	WSAData data;
	WSAStartup(MAKEWORD(2, 2), &data);

	local.sin_family = AF_INET;
	inet_pton(AF_INET, srcIP, &local.sin_addr.s_addr);
	local.sin_port = htons(0); //recieve

	dest.sin_family = AF_INET;
	inet_pton(AF_INET, destIP, &dest.sin_addr.s_addr);
	dest.sin_port = htons(3514);

	SOCKET s = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
	bind(s, (sockaddr*)&local, sizeof(local));

	sendto(s, pkt, strlen(pkt), 0, (sockaddr*)&dest, sizeof(dest));

	closesocket(s);
	WSACleanup();
}


void CmyChat07Dlg::OnBnClickedCancel()
{
	// TODO: Add your control notification handler code here
	//Clean all sending information
	
	//CString typingChat;
	//GetDlgItemText(IDC_EDIT_CHAT, typingChat);
	//cstr = "\r\n";
	//SetDlgItemText(IDC_STATIC, cstr);

	CDialogEx::OnCancel();
}
